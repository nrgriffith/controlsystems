% Given parameters
OS = 0.07;
t_s = 2.5; % seconds
t_r = 1.2; % seconds