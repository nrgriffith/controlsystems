% Given constants
k1 = 6.8298;
k2 = -8.9617;
k3 = 3.7447;
k4 = 1;