K=1;
s=tf('s');
rootlocus
simulate
verify