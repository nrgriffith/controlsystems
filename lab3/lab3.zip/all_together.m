rootlocus
simulate
verify